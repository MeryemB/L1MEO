# a)
print('première partie')
print('deuxième partie')
print('première partie','avec espace deuxième partie')
print('première partie'+' sans espace deuxième partie')

print('Guillemets simples')
print("double Guillemets")

# b)
X1=2018
X2="2018"

# sol (c)
print(X1+X1)
print(X2+X2)

# sol (d)
a=5
print('première partie',a)

