a = 7.692
b = 21.8
resultat = a + b
# affichage simple
print("La somme des deux nombres donnés est :", resultat)
# affichage formate
print("La somme des deux nombres donnés est : {:.1f}".format(resultat))

c = 25
francs = c * 6.55957
print("La somme convertie en francs est égale à : ", francs)
