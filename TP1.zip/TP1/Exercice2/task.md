Exercice
-

1) Définissez deux variables : **_a_** et **_b_** ayant pour valeur respectivement 5 et 3.

2) Afficher la phrase suivante : **_a_** vaut 5 et **_b_** vaut 15 , leur somme fait 8

3) Demandez en Python « **_a_** est-il un multiple de **_b_** ? ».

4) Écrivez les lignes de code permettant d’échanger les valeurs de **_a_** et **_b_**, en utilisant une variable temporaire tmp.

5) Échangez à nouveau les valeurs de **_a_** et **_b_**, mais sans utiliser de variable temporaire.

>que peut-on déduir?
