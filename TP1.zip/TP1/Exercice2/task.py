
# sol 1

a=5
b=3

# sol 2
print("a vaut ",a,"b vaut",b,"leur somme fait",a+b)

# sol 3
print(a, "est-il un multiple de",b,"?")

# sol 4
c=a
a=b
b=c

# sol 5
a = a+b
b = a-b
a = a-b

