**Rappel:**

- La fonction print() : pour afficher des messages et des valeurs
- La fonction int(a) : permet la conversion de la variable a en
 entier
- La fonction str(b) : permet la conversion de la variable b en chaine
 de caractère

Écrire un programme, qui définit 3 variables de type réel (float)
représentant des notes (note1, note2, note3). Affectez les variables note1, note2, note3
 par les valeurs 15.5, 12.75 et 14.25 respectivement. Ensuite, calculez la moyenne.
 Affichez la valeur de la variable **_moyenne_** en ajoutant le message suivant :
  “ La moyenne des trois notes est : “ Que se passe-t-il lorsque 
  vous exécutez le programme ? Gérez le cas où la variable moyenne
    n’est pas convertible en chaine de caractère.
    
    