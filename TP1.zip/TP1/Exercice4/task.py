# la première note
note1 = 15.5
# la deuxieme note
note2 = 12.75
# la troisieme note
note3 = 14.25
# calculer la moyenne
moyenne = (note1 + note2 + note3) / 3
# afficher le resultat
print("La moyenne des trois notes est : " + str(moyenne))
