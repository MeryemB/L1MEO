**Remarques préliminaires**

- **Input**  : Permet la saisie d'une valeur au clavier. On peut 
invoquer la fonction input() en laissant les parenthèses vides. On
 peut aussi y placer en argument un message explicatif destiné 
 à l’utilisateur. 
 Exemple: a = input('Entrer la valeur de a : ')


Ecrivez un programme python qui permet la saisie d’une valeur représentant le montant
 d’un porte monnaie. Stockez cette valeur dans une variable nommée 
 **_porte_monnaie_**. Puis, déclarez une variable nommée **_produit_** 
représentant un produit qui coûte **45** euros. 
Pour finir, affichez la nouvelle valeur du porte monnaie après l’achat du produit.