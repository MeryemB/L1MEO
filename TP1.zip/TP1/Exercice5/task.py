porte_monnaie = int(input("Entrer le montant de votre porte monnaie : "))
produit = 45
#Achat du produit
porte_monnaie = porte_monnaie - produit
print("La nouvelle valeur du porte monnaie après l’achat du produit est: "+str(porte_monnaie) +" euros")
