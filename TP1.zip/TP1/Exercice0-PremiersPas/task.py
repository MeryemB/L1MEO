# Solutions
#Shell

# a.
# $ ls

# b.
# $ mkdir Documents

# c.
# $ cd Documents
# $ mkdir Septembre_2018

# d.
# $ cd Septembre_2018
# $ touch tp1.py
# $ touch tp2.py

# e.
# $ pwd

#f.
# $ cd ../..
# $ ls -R

#g.

#Home
#    Documents
#        Septembre_2018
#            tp1.py
#            tp2.py

#h.
# $ mv -R Documents/Septembre_2018/*.py Documents/

#i
# $ rmdir Septembre_2018

#Python console

5+10
7 - 9  # les espaces sont optionnels
7 + 3 * 5   # la hiérarchie des opérations mathématiques
            # est-elle respectée ?
(7 +3) *5
20/6
8,7 / 5  #Erreur !
         # le séparateur décimal est toujours un point, et non une virgule!

20.0 / 3
8./5   #type float


4 * 2.5 / 3.3  #

